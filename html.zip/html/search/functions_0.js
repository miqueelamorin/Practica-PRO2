var searchData=
[
  ['actualizar_5festadisticas_0',['actualizar_estadisticas',['../class_cjt___jugadores.html#a568645add15663ae5ad455db748500de',1,'Cjt_Jugadores::actualizar_estadisticas()'],['../class_jugador.html#a5a306ce7943dbecf5c208a0ccf9186b5',1,'Jugador::actualizar_estadisticas(int tj, int pg, int pp, int sg, int sp, int jg, int jp)']]],
  ['actualizar_5fposicion_1',['actualizar_posicion',['../class_jugador.html#ab38877c9673b1de746f5a3642b8b9344',1,'Jugador']]],
  ['actualizar_5fpuntos_5ftorneos_5fescribir_2',['actualizar_puntos_torneos_escribir',['../class_torneo.html#a4ccb7738cf9e34187313c223800d7bf3',1,'Torneo']]],
  ['anadir_5fjugador_3',['anadir_jugador',['../class_cjt___jugadores.html#a732b3275188d15d648b87fa78f80d0e0',1,'Cjt_Jugadores']]],
  ['anadir_5ftorneo_4',['anadir_torneo',['../class_circuito.html#ad9b662ac94f25df84874259656d0308d',1,'Circuito']]]
];
