var searchData=
[
  ['sg_0',['sg',['../class_jugador.html#a678970fa93782e3e68f939c37fff5030',1,'Jugador']]],
  ['sp_1',['sp',['../class_jugador.html#a5bed10a21acb0c437828df282050b2ab',1,'Jugador']]],
  ['sumar_5fpuntos_2',['sumar_puntos',['../class_cjt___jugadores.html#ae7b5ee0d4dfd3379a9aaad67d40fd51e',1,'Cjt_Jugadores']]]
];
