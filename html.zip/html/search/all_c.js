var searchData=
[
  ['ranking_0',['ranking',['../class_cjt___jugadores.html#a2e870e07bbcbd6b0509824b6869923d0',1,'Cjt_Jugadores']]],
  ['restar_5fpuntos_5franking_1',['restar_puntos_ranking',['../class_torneo.html#a4577103669b164c8aad8237eaad167c1',1,'Torneo']]],
  ['resultados_2',['resultados',['../class_torneo.html#ad8987fdf5aedc7754d82adb87c186ee4',1,'Torneo']]]
];
