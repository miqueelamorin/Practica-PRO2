var searchData=
[
  ['jrank_0',['jrank',['../struct_cjt___jugadores_1_1jrank.html',1,'Cjt_Jugadores']]],
  ['jugador_1',['Jugador',['../class_jugador.html',1,'']]]
];
