var searchData=
[
  ['imprimir_5femparejamientos_0',['imprimir_emparejamientos',['../class_torneo.html#a8b98e54908f8354c553011d1156d9a84',1,'Torneo']]],
  ['imprimir_5fresultados_1',['imprimir_resultados',['../class_torneo.html#a5de65fd4f2a3ef214e8de7867b97c32d',1,'Torneo']]],
  ['iniciar_5ftorneo_2',['iniciar_torneo',['../class_circuito.html#a8b2e937c194f2bbd24515d0df74fcecb',1,'Circuito']]]
];
