var searchData=
[
  ['buscar_5fjugador_0',['buscar_jugador',['../class_cjt___jugadores.html#a10d337c9870407712dda6e09a319e680',1,'Cjt_Jugadores']]]
];
