var searchData=
[
  ['restar_5fpuntos_5franking_0',['restar_puntos_ranking',['../class_torneo.html#a4577103669b164c8aad8237eaad167c1',1,'Torneo']]],
  ['resultados_1',['resultados',['../class_torneo.html#ad8987fdf5aedc7754d82adb87c186ee4',1,'Torneo']]]
];
