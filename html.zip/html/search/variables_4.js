var searchData=
[
  ['nombre_0',['nombre',['../struct_cjt___jugadores_1_1jrank.html#aab48b7b320183bd65bf0a81f59f85bb7',1,'Cjt_Jugadores::jrank']]]
];
