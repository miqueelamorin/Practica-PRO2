var searchData=
[
  ['ranking_0',['ranking',['../class_cjt___jugadores.html#a2e870e07bbcbd6b0509824b6869923d0',1,'Cjt_Jugadores']]]
];
