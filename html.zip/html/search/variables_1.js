var searchData=
[
  ['c_0',['C',['../class_categorias.html#a2ee6d47960b317949f7034b82d2e86db',1,'Categorias']]],
  ['categoria_1',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['categorias_2',['categorias',['../class_categorias.html#a4830c4061b6844f845046464ac4e3f6a',1,'Categorias']]],
  ['circuito_3',['circuito',['../class_circuito.html#a844be1f9b256ec8fc41a8acba9e99412',1,'Circuito']]],
  ['cjt_4',['cjt',['../class_cjt___jugadores.html#a13fc36e93247d53bf4b4489e41a8a62f',1,'Cjt_Jugadores']]]
];
