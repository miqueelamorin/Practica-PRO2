var searchData=
[
  ['jg_0',['jg',['../class_jugador.html#a53ac73c3dc720ca6e66406b309077472',1,'Jugador']]],
  ['jp_1',['jp',['../class_jugador.html#a306eb04292a1aa300a39c2464c1368fd',1,'Jugador']]],
  ['jrank_2',['jrank',['../struct_cjt___jugadores_1_1jrank.html',1,'Cjt_Jugadores']]],
  ['jugador_3',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ecc_4',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_5',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
