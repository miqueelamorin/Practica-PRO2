var searchData=
[
  ['ordenar_5franking_0',['ordenar_ranking',['../class_cjt___jugadores.html#aa3e654d501a23e4f43a1a61cdf7507cc',1,'Cjt_Jugadores']]]
];
