var searchData=
[
  ['tabla_5fpuntos_0',['tabla_puntos',['../class_categorias.html#a2b9726f5a53669e2a6ca84c48e86f8e6',1,'Categorias']]],
  ['tj_1',['tj',['../class_jugador.html#a783605edb1eb429a0a3e0101829df679',1,'Jugador']]],
  ['torneo_2',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#adf7d17b208dce369483468b6f5f96587',1,'Torneo::Torneo(int cat)']]],
  ['torneo_2ecc_3',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_4',['Torneo.hh',['../_torneo_8hh.html',1,'']]]
];
