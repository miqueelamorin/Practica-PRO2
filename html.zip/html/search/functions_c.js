var searchData=
[
  ['sumar_5fpuntos_0',['sumar_puntos',['../class_cjt___jugadores.html#ae7b5ee0d4dfd3379a9aaad67d40fd51e',1,'Cjt_Jugadores']]]
];
