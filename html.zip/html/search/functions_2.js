var searchData=
[
  ['calcular_5factualizar_5festadisticas_0',['calcular_actualizar_estadisticas',['../class_torneo.html#ad9c6d5528cbf3deb61cc9db663775406',1,'Torneo']]],
  ['categoria_5fmax_1',['categoria_max',['../class_categorias.html#a74e86f127d3b60e5bea96b1ae2e28de4',1,'Categorias']]],
  ['categorias_2',['Categorias',['../class_categorias.html#a9c8353e5665cf7c4f64d7165776518ac',1,'Categorias']]],
  ['circuito_3',['Circuito',['../class_circuito.html#ad7d5962b0160536b15609afaf99083c7',1,'Circuito']]],
  ['cjt_5fjugadores_4',['Cjt_Jugadores',['../class_cjt___jugadores.html#a2e7a3bb35253088c8b66d6cfbc89742f',1,'Cjt_Jugadores']]],
  ['comp_5',['comp',['../class_cjt___jugadores.html#ad2609d45dc343725e0b31dd26aa1e79c',1,'Cjt_Jugadores']]],
  ['consultar_5fposicion_6',['consultar_posicion',['../class_jugador.html#a068a450958346b4a65b0c10a77a23bdc',1,'Jugador']]],
  ['consultar_5fpuntos_7',['consultar_puntos',['../class_categorias.html#a7f8a0cc0030f0cad4ee09d51f89d5f6c',1,'Categorias::consultar_puntos()'],['../class_cjt___jugadores.html#af17c15164bd84637045a320173e98309',1,'Cjt_Jugadores::consultar_puntos()']]],
  ['cuadro_5femparejamientos_8',['cuadro_emparejamientos',['../class_torneo.html#aac11f5ce5316958dc3311ccda82fd10c',1,'Torneo']]],
  ['cuadro_5fresultados_9',['cuadro_resultados',['../class_torneo.html#a04f3bacb9c1285acdaa57eced00ef16c',1,'Torneo']]]
];
