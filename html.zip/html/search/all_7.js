var searchData=
[
  ['leer_0',['leer',['../class_categorias.html#a22732c5c60713f1fdac6823ccd2852bb',1,'Categorias::leer()'],['../class_circuito.html#a176b795f0b67ee7891cff4ca35fa2f36',1,'Circuito::leer()'],['../class_cjt___jugadores.html#a753d3bc139ca9107cfc94d464653d473',1,'Cjt_Jugadores::leer()']]],
  ['leer_5finscritos_1',['leer_inscritos',['../class_torneo.html#a1846c195f8f3f4c57d893997090b80a2',1,'Torneo']]],
  ['listar_5fcategorias_2',['listar_categorias',['../class_categorias.html#aefa0da1a2c42543dea5447399f4bc6d0',1,'Categorias']]],
  ['listar_5fjugador_3',['listar_jugador',['../class_cjt___jugadores.html#a4cc6e7db64a3f5df7f77445cd66e5e8e',1,'Cjt_Jugadores']]],
  ['listar_5fjugadores_4',['listar_jugadores',['../class_cjt___jugadores.html#a1a96c570a483da224c882216d3080dd0',1,'Cjt_Jugadores']]],
  ['listar_5franking_5',['listar_ranking',['../class_cjt___jugadores.html#a4c60a851b0212b02d07f2048d13188d6',1,'Cjt_Jugadores']]],
  ['listar_5ftorneos_6',['listar_torneos',['../class_circuito.html#a42837e79b76052c098eba88b854769e6',1,'Circuito']]]
];
