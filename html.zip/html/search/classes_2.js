var searchData=
[
  ['torneo_0',['Torneo',['../class_torneo.html',1,'']]]
];
