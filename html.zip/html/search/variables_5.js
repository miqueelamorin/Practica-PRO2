var searchData=
[
  ['pg_0',['pg',['../class_jugador.html#ab254a72417747985ffaf53b0508e5e31',1,'Jugador']]],
  ['pos_1',['pos',['../class_jugador.html#a25a7eeb0d334b2fe60bb490704c6626d',1,'Jugador']]],
  ['pos_5fant_2',['pos_ant',['../struct_cjt___jugadores_1_1jrank.html#ac997f958c4d48dd39ecc596b6dd6dbee',1,'Cjt_Jugadores::jrank']]],
  ['pp_3',['pp',['../class_jugador.html#a90af14828909d3c5cd3fb4a285e96daf',1,'Jugador']]],
  ['puntos_4',['puntos',['../struct_cjt___jugadores_1_1jrank.html#a8b9dc2fa3d382ab7bb165013525e2dc1',1,'Cjt_Jugadores::jrank']]]
];
