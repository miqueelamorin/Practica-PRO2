var searchData=
[
  ['nombre_0',['nombre',['../struct_cjt___jugadores_1_1jrank.html#aab48b7b320183bd65bf0a81f59f85bb7',1,'Cjt_Jugadores::jrank']]],
  ['nombre_5fcategoria_1',['nombre_categoria',['../class_categorias.html#a3c7404d08d0261ef04a81238c83d62ae',1,'Categorias']]],
  ['numero_5fjugadores_2',['numero_jugadores',['../class_cjt___jugadores.html#ac0a8e34bec7aa6ef3ba33e6bb9eeaeb3',1,'Cjt_Jugadores']]],
  ['numero_5ftorneos_3',['numero_torneos',['../class_circuito.html#aabea9b1704ae20329fe5aa4e49aace6d',1,'Circuito']]]
];
