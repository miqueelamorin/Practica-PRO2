var searchData=
[
  ['tabla_5fpuntos_0',['tabla_puntos',['../class_categorias.html#a2b9726f5a53669e2a6ca84c48e86f8e6',1,'Categorias']]],
  ['tj_1',['tj',['../class_jugador.html#a783605edb1eb429a0a3e0101829df679',1,'Jugador']]]
];
