var searchData=
[
  ['ed_5factual_0',['ed_actual',['../class_torneo.html#a6d5637290c5cfe6524daca0521478c13',1,'Torneo']]],
  ['ed_5fanterior_1',['ed_anterior',['../class_torneo.html#ae3f8489e51c947eed818b493963e282e',1,'Torneo']]]
];
